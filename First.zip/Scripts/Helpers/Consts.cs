public static class Consts
{
    public static string targetTag = "Target";
    public static string centerTag = "Center";
    public static string objectChecker = "Checker";
}
